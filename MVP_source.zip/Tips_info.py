import time

path = '/Users/desmo/OneDrive/Desktop/MVP(APP)/images/Fig1.png'
read_instruct = open("typing_info.txt", "r")
info_text = read_instruct.readline()
read_instruct.close()


while True:


    read_file = open("tips_comm.txt", "r")

    first_line = read_file.readline()
    
    if (first_line == "run"):

        read_file.close()

        write2 = open("tips_comm.txt", "w")
        write2.write(path + "\n")
        write2.write(info_text)
        write2.close()



