from ast import While
from cgitb import reset
from importlib.resources import open_binary
from tkinter import *
import time
import random
import threading
from PIL import ImageTk, Image

Gen_text = "Generate new text Button:\nAllows you to generate new text to practice on."
Res_text = "Result Button:\nAllows you to examine your scores in greater depth. Displaying words per minute(WPM), and accuracy."
Reset_text = " Reset/Save Button:\nThis button allows you to reset your text box and save your pervious results."
Tips_text = "Tips and Information Button:\nFor more tips and Info on typing, and finger placement, use this button."
var = "TEXT WILL BE GENERATED HERE"
class typingTestClass:

    def __init__(self):

        self.window = Tk()
        self.window.geometry("1450x850+25+25")
        self.window.title("Speed Typing test")
        #window/gui

        # Title Label
         #==================================================================================
        self.main_title =  Label(self.window, text= "Speed Typing-Test", font=("Times", 40))
        self.main_title.place(x=500,y=10)

        
        #instruction label
         #==================================================================================
        self.instruct_label = Label(self.window, text= "Instructions!!!",font=("Times", 25))
        self.instruct_label.place(x=50, y= 20)

        # Generated txt area.
         #==================================================================================
        self.area_frame = LabelFrame(self.window, text="Generated Text Area", font=("Times", 15),width=700,height=250)
        self.area_frame.place(x=400, y=100)
        self.area_frame.propagate(False)

        self.paragraph = Message(self.area_frame, text=var,font=("Times", 14),aspect=400)
        self.paragraph.pack(padx=10, pady=10)
        

        # instruction messages aspect
         #==================================================================================
        self.Gen_message1 = Message(self.window, text = Gen_text,font=("Times", 15), aspect=200)
        self.Gen_message1.place(x=50, y= 70)

        self.res_message = Message(self.window, text = Res_text, font=("Times", 15), aspect=200)
        self.res_message.place(x=50, y= 200)

        self.rest_mes =  Message(self.window, text = Reset_text, font=("Times", 15), aspect=200)
        self.rest_mes.place(x=50, y= 350)

        self.tips_message =  Message(self.window, text = Tips_text, font=("Times", 15), aspect=200)
        self.tips_message.place(x=50, y= 500)


        #text input box.
         #==================================================================================
        self.text_area = Text(self.window,height= 15,font=("Times", 14),wrap=WORD)
        self.text_area.place(x=400, y=380)
        self.text_area.bind("<KeyRelease>",self.start_typing)

        #general buttons:
         #==================================================================================

        # results button
        self.results = Button(self.window, text = "Test Results", font=("Times",15),command=self.show_store)
        self.results.place(x=800,y=740)

        # reset button
        self.reset_page = Button(self.window, text = "Reset/Save",font=("Times", 15),command=self.reset_text)
        self.reset_page.place(x=540,y=740)

        
        self.generate_text = Button(self.window, text = "Generate New Text", font=("Times", 15,), command= self.new_text)
        self.generate_text.place(x=250,y=740)

        self.tips_info = Button(self.window, text = "Tips For Typing", font=("Times",15),command=self.popup_screen)
        self.tips_info.place(x=1050,y=740)


        #Timer label
        self.Timer = Label(self.window, text= "Rate of Chars: 0:00\n TIME:0:00", font=("Times", 20))
        self.Timer.place(x=1150,y=350)

        self.count = 0
        self.isRunning = False
        self.previous_time = 0


        self.window.mainloop()


    #fucntions 
     #==================================================================================
    def new_text(self):
        write2_file = open("gen_comm.txt","w")
        write2_file.write("request")
        write2_file.close()
        time.sleep(1)

        readin_file = open("gen_comm.txt","r")
        string_holder = readin_file.readline()
        readin_file.close()
        self.paragraph['text'] = string_holder

    #Click tips_info function;

    def popup_screen(self):
        #send over run statment
        file_comm = open("tips_comm.txt", "w")
        file_comm.write("run")
        file_comm.close()
        time.sleep(1)

        file_com2 = open("tips_comm.txt", "r")
        image_path = file_com2.readline()
        message_line = file_com2.readline()
        file_com2.close()

        #pop up screen
        popup = Toplevel(self.window)
        popup.title("Tips To Typing")
        popup.geometry("1000x600+300+50")

        my_pic = Image.open("pic1.gif")

        new_pic = my_pic.resize((550,350), Image.ANTIALIAS)

        photoIm = ImageTk.PhotoImage(new_pic)

        imageLabel = Label(popup, image=photoIm,width=550,height=350)
        imageLabel.pack()
        info_type = Message(popup, text=message_line, font=("Times", 20), aspect=400)
        info_type.pack()
        destroy = Button(popup, text="Close!!",font=("Times", 25), command= popup.destroy)
        destroy.pack()
        popup.mainloop()


        #================================================
        #input fuctionality

    def start_typing(self,event):
        if not self.isRunning:
            if not event.keycode in [16]:
                self.isRunning = True

                val = threading.Thread(target=self.time_thread)
                val.start()
        if self.paragraph.cget('text').startswith(self.text_area.get("1.0",'end-1c')):
            self.text_area.config(fg="blue")
        else:
            self.text_area.config(fg="red")

        if self.text_area.get("1.0",'end-1c') == self.paragraph.cget('text'):
            self.isRunning = False
            self.text_area.config(fg="green")
            

    def time_thread(self):
        while self.isRunning:
            time.sleep(0.1)
            self.count += 0.1

            characters_per_min = len(self.text_area.get("1.0",'end-1c')) / self.count

            characters_per_min =  characters_per_min * 60
            self.Timer.config(text=f"Rate of Chars: { characters_per_min:.2f}\n TIME: {self.count:.2f}")
            


    def reset_text(self):
        if self.count > 0:
            self.previous_time = self.count
            self.previous_time = int((len(self.text_area.get("1.0",'end-1c').split(" "))/ self.previous_time ) * 60)
        print(self.previous_time)
        self.count = 0
        self.isRunning = False
        self.Timer.config( text= "Rate of Chars: 0:00,\n, TIME:0:00")
        self.text_area.delete("1.0",END)



    def show_store(self):

        if self.isRunning == False:

            write_file = open("res_coms.txt", "w")
            holder = str(self.previous_time)
            write_file.write(holder)
            write_file.close()
            time.sleep(1)

            read_res = open("res_coms.txt", "r")
            result_line = read_res.readline()

            #pop up screen
            res_window = Toplevel(self.window)
            res_window.title("Test Results")
            res_window.geometry("600x600+300+50")

            label_wpm = Label(res_window,text= "Your WPM = " + holder,font=("Times", 40))
            label_wpm.pack(pady=10)
            text_wpm = Label(res_window,text=result_line,font=("Times", 30))
            text_wpm.pack(pady=10)
            close_button = Button(res_window,text="RETURN",font=("Times", 30), command=res_window.destroy)
            close_button.pack(pady=15)



        



        









typingTestClass()












