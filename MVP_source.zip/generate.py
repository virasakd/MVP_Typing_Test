import time
import random


text_list = open('Text1.txt',"r").read().split("\n")



while True:

    read_com = open("gen_comm.txt", "r")
    line = read_com.readline()

    if(line == "request"):

        read_com.close()

        string = random.choice(text_list)

        write_to = open("gen_comm.txt", "w")
        write_to.write(string)
        write_to.close()
       


